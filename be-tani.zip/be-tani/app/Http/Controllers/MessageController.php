<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function index(){
        $message = Message::orderBy('status', 'ASC')->latest()->filter(request(['user', 'status']))->paginate(5)->withQueryString();

        $pesanUnread = Message::where('status', 'Belum Dibaca')->filter(request(['user', 'status']))->paginate(5)->withQueryString();

        $pesanRead = Message::where('status', 'Sudah Dibaca')->filter(request(['user', 'status']))->paginate(5)->withQueryString();
    
        $pesanReplied = Message::where('status', 'Sudah Dibalas')->filter(request(['user', 'status']))->paginate(5)->withQueryString();

    return view('message.index', [
        'pesanUnread' => $pesanUnread,
        'pesanRead' => $pesanRead,
        'pesanReplied' => $pesanReplied,
        'message' => $message,
    ]);
    }

    public function readMessage(Message $message){
        Message::where('id', $message->id)->update(array('status' => '1'));

        return view('message.show', [
            'message' => $message
        ]);
    }

    public function replyMessage(Message $message)
    {
        $message->update(['status' => 'Sudah Dibalas']);

        return redirect('pesan')->with('success', 'Berhasil Membalas Pesan');
    }

    public function destroy(Message $message)
    {
        $message->delete();

        return redirect('pesan')->with('success', 'Berhasil Menghapus Pesan yang Sudah Dibalas');
    }

    
}
