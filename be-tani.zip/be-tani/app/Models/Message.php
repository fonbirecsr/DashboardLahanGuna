<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Message extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    public function scopeFilter(Builder $query, array $filters): Builder
    {
        if (isset($filters['user'])) {
            $query->where('user_id', $filters['user']);
        }

        if (isset($filters['status'])) {
            switch ($filters['status']) {
                case 'Sudah Dibalas':
                    $query->where('status', 'Sudah Dibalas');
                    break;
                case 'Sudah Dibaca':
                    $query->where('status', 'Sudah Dibaca');
                    break;
                default:
                    $query->where('status', 'Belum Dibaca');
                    break;
            }
        }

        return $query;
    }

    public function user(){
        return $this->belongsTo(User::class);
    }
}
