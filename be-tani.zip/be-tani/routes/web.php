<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MessageController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::group(['middleware' => 'auth'], function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');


    Route::resource('/modul', DocumentController::class);

    Route::get('/pesan', [MessageController::class, 'index'])->name('pesan');
    Route::get('/pesan/{message:id}', [MessageController::class, 'readMessage'])->name('pesan');
    Route::put('/pesan/{message}/balas', [MessageController::class, 'replyMessage'])->name('pesan.balas');
    Route::delete('/pesan/{message}', [MessageController::class, 'destroy'])->name('pesan.hapus');
});




Route::get('/login', [LoginController::class, 'index'])->middleware('guest')->name('login');;
Route::post('/login',  [LoginController::class, 'authenticate']);
Route::post('/logout',  [LoginController::class, 'logout']);

