<div id="loading-alert">
    <div class="alert alert-success" role="alert" id="loading-text">
        <div class="spinner-border text-light" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        Sedang mengambil data..
    </div>
</div>