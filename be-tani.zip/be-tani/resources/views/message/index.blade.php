@extends('layouts.main', ['title' => 'Pesan', 'page_heading' => 'Pesan'])

@section('content')
@include('utilities.alert-flash-message')
<section class="row">
	<nav>
		<div class="nav nav-tabs mb-2" id="nav-tab" role="tablist">
		  <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Belum Dibaca</button>
		  <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Sudah Dibaca</button>
		  <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Sudah Dibalas</button>
		</div>
	  </nav>
	  <div class="tab-content" id="nav-tabContent">
		<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">
			@foreach ($pesanUnread as $item)
				<div class="card border">
					<h5 class="card-header">{{ $item->user->email }} - Belum Dibaca</h5>
					<div class="card-body">
						<p class="card-text">{{ $item->subject }}</p>
						<div class="btn-group me-2" role="group">
							<form action="/pesan/{{ $item->id }}">
								@method('put')
								@csrf
								<button class="btn btn-primary">Baca Pesan</button>
							</form>
						</div>
						<div class="btn-group me-2" role="group">
							@if ($item->status == 'Sudah Dibalas')
								<form action="{{ route('pesan.hapus', $item->id) }}" method="POST">
									@csrf
									@method('delete')
									<button type="submit" class="btn btn-danger">Hapus Pesan</button>
								</form>
							@endif
						</div>
						{{-- <a href="#" class="btn btn-primary">Baca Pesan</a> --}}
					</div>
				</div>
			@endforeach
			{{ $pesanUnread->appends(request()->query())->links() }}
		</div>
		<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
			@foreach ($pesanRead as $item)
				<div class="card border">
					<h5 class="card-header">{{ $item->user->email }} - Sudah Dibaca</h5>
					<div class="card-body">
						<p class="card-text">{{ $item->subject }}</p>
						<div class="btn-group me-2" role="group">
							<form action="/pesan/{{ $item->id }}">
								@method('put')
								@csrf
								<button class="btn btn-primary">Baca Pesan</button>
							</form>
						</div>
						<div class="btn-group me-2" role="group">
							@if ($item->status == 'Sudah Dibalas')
								<form action="{{ route('pesan.hapus', $item->id) }}" method="POST">
									@csrf
									@method('delete')
									<button type="submit" class="btn btn-danger">Hapus Pesan</button>
								</form>
							@endif
						</div>
						{{-- <a href="#" class="btn btn-primary">Baca Pesan</a> --}}
					</div>
				</div>
			@endforeach
			{{ $pesanRead->appends(request()->query())->links() }}
		</div>
		<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab" tabindex="0">
			@foreach ($pesanReplied as $item)
				<div class="card border">
					<h5 class="card-header">{{ $item->user->email }} - Sudah Dibalas</h5>
					<div class="card-body">
						<p class="card-text">{{ $item->subject }}</p>
						<div class="btn-group me-2" role="group">
							<form action="/pesan/{{ $item->id }}">
								@method('put')
								@csrf
								<button class="btn btn-primary">Baca Pesan</button>
							</form>
						</div>
						<div class="btn-group me-2" role="group">
							@if ($item->status == 'Sudah Dibalas')
								<form action="{{ route('pesan.hapus', $item->id) }}" method="POST">
									@csrf
									@method('delete')
									<button type="submit" class="btn btn-danger">Hapus Pesan</button>
								</form>
							@endif
						</div>
						{{-- <a href="#" class="btn btn-primary">Baca Pesan</a> --}}
					</div>
				</div>
			@endforeach
			{{ $pesanReplied->appends(request()->query())->links() }}
		</div>
	  </div>
</section>
@endsection
{{-- Import modal form tambah data --}}
@push('modal')
@include('modul.modal.create')
{{-- @include('pemasukan.modal.edit') --}}
@endpush

{{-- @push('js')
@include('dashboard.script')
@endpush --}}
